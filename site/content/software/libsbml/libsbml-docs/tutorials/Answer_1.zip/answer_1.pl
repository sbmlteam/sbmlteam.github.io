#!/usr/bin/perl
# -*-Perl-*-
# 
# @file    answer_1.pl
# @brief   Solution to tutorial example exercise 1
# @author  Sarah Keating
# @author  Frank Bergmann (perl port)
# 

use blib '../../src/bindings/perl';
use LibSBML;
use strict;

if (@ARGV != 1) {
  print "Usage: answer_1 input-filename\n\n";
  exit 2;
}

my $d = LibSBML::readSBML($ARGV[0]);
if ($d->getNumErrors() > 0){
  $d->printErrors();
}
else
{
  my $m = $d->getModel();
  
  for (my $n = 0; $n <$m->getNumReactions(); $n++) {  
    my $r = $m->getReaction($n);
    # print reaction id
    print "Reaction " . $r->getId() . ": ";
    
    # look at reactants
    my $numReactants = $r->getNumReactants();
    if ($numReactants > 1) {
	
      my $s = $m->getSpecies($r->getReactant(0)->getSpecies());
      print $s->getName() , " ";
	  for (my $k = 1; $k <$numReactants; $k++) {  
        # get species referred to by the reaction
        $s = $m->getSpecies($r->getReactant($k)->getSpecies());
        print "+ " . $s->getName() . " ";
	  }
	}
    elsif ($numReactants == 1)
	{
      # get species referred to by the reaction
      my $s = $m->getSpecies($r->getReactant(0)->getSpecies());
      print $s->getName() . " ";
    }
    if ($r->getReversible() == 1)
	{
      print "<=> ";
	}
    else
	{
      print "=> ";
	}

	# look at products
    my $numProducts = $r->getNumProducts();
    if ($numProducts > 1)
	{
      my $s = $m->getSpecies($r->getProduct(0)->getSpecies());
      print $s->getName() . " ";
	  for (my $k = 1; $k <$numProducts; $k++) {  
        # get species referred to by the reaction
        $s = $m->getSpecies($r->getProduct($k)->getSpecies());
        print "+ " . $s->getName() . " ";
	  }
	}
    elsif ($numProducts == 1)
	{
      # get species referred to by the reaction
      my $s = $m->getSpecies($r->getProduct(0)->getSpecies());
      print $s->getName() . " ";
	}
    print "\n\n";
	}
}