# 
# @file    answer_1.py
# @brief   Solution to tutorial example exercise 1
# @author  Sarah Keating
# @author  Frank Bergmann (python port)
# 

import sys
from libsbml import *

if len(sys.argv) != 2:
  sys.exit ("Usage: answer_1 input-filename\n\n")

d = readSBML(sys.argv[1]);
if d.getNumErrors() > 0:
  d.printErrors();
else:
  m = d.getModel();
  
  for n in range (0, m.getNumReactions()):
    r = m.getReaction(n);
    # print reaction id
    print "Reaction " , r.getId() , ": ",
    
    # look at reactants
    numReactants = r.getNumReactants();
    if (numReactants > 1):
      s = m.getSpecies(r.getReactant(0).getSpecies());
      print s.getName() , " ",
      for k in range (1, numReactants):
        # get species referred to by the reaction
        s = m.getSpecies(r.getReactant(k).getSpecies());
        print "+ " , s.getName() , " ",
    elif (numReactants == 1):
      # get species referred to by the reaction
      s = m.getSpecies(r.getReactant(0).getSpecies());
      print s.getName() , " ",
    
    if (r.getReversible() == True):
      print "<=> ",
    else:
      print "=> ",

	# look at products
    numProducts = r.getNumProducts();
    if (numProducts > 1):
      s = m.getSpecies(r.getProduct(0).getSpecies());
      print s.getName() , " ",
      for k in range (1, numProducts):
        # get species referred to by the reaction
        s = m.getSpecies(r.getProduct(k).getSpecies());
        print "+ " , s.getName() , " ",
    elif (numProducts == 1):
      # get species referred to by the reaction
      s = m.getSpecies(r.getProduct(0).getSpecies());
      print s.getName() , " ",
    print "\n\n"
