using System;
using libsbmlcs;


/// 
/// @file    answer_1.cs
/// @brief   Solution to tutorial example exercise 1
/// @author  Sarah Keating
/// @author  Frank Bergmann (C# port)
/// 

public class answer_1 {

	public static void Main(String[] args) {

		if (args.Length != 1)
		{
			Console.WriteLine("Usage: answer_1 input-filename");
			Environment.Exit(2);
		}

		SBMLDocument d = libsbml.readSBML(args[0]);
		if ( d.getNumErrors() > 0)
		{
			d.printErrors();
		}
		else
		{
			Model  m = d.getModel();
			Species s;
			for (int n = 0; n < m.getNumReactions(); n++)
			{
				Reaction r = m.getReaction(n);
				// print reaction id
				Console.Write("Reaction " + r.getId() + ": ");

				// look at reactants
				int numReactants = (int)r.getNumReactants();
				if (numReactants > 1)
				{
					s = m.getSpecies(r.getReactant(0).getSpecies());
					Console.Write(s.getName() + " ");
					for (int k = 1; k < numReactants; k++)
					{
						// get species referred to by the reaction
						s = m.getSpecies(r.getReactant(k).getSpecies());
						Console.Write("+ " + s.getName() + " ");
					}
				}
				else if (numReactants == 1)
				{
					// get species referred to by the reaction
					s = m.getSpecies(r.getReactant(0).getSpecies());
					Console.Write(s.getName() + " ");
				}
				if (r.getReversible() == true)
				{
					Console.Write("<=> ");
				}
				else
				{
					Console.Write("=> ");
				}
				// look at products
				int numProducts = (int)r.getNumProducts();
				if (numProducts > 1)
				{
					s = m.getSpecies(r.getProduct(0).getSpecies());
					Console.Write(s.getName() + " ");
					for (int k = 1; k < numProducts; k++)
					{
						// get species referred to by the reaction
						s = m.getSpecies(r.getProduct(k).getSpecies());
						Console.Write("+ " + s.getName() + " ");
					}
				}
				else if (numProducts == 1)
				{
					// get species referred to by the reaction
					s = m.getSpecies(r.getProduct(0).getSpecies());
					Console.Write(s.getName() + " ");
				}

				Console.WriteLine("\n");

			}
		}
	}
}
